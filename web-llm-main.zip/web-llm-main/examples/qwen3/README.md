### OpenAI API Demos w/ Qwen3

Run `npm install` first, followed by `npm start`.

Note if you would like to hack WebLLM core package,
you can change web-llm dependencies as `"file:../.."`, and follow the build from source
instruction in the project to build webllm locally. This option is only recommended
if you would like to hack WebLLM core package.
