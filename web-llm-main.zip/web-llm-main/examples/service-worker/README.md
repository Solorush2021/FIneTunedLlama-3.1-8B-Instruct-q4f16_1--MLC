# WebLLM Service Worker Example

This example shows how we can create a page with Web-LLM running in service worker.

```bash
npm install
npm run build
```
